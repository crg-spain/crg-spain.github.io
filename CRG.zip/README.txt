Englishman (E), Indian (I) and an academic (A) (with thus so particular demeanor & culture) are asked:
Excuse me, what's your opinion on the meat shortage?
E:
What's opinion?
I:
What's meat?
A:
What's excuse-me?

This is a temporary storage for all documents concerning a case of Research Misconduct at CRG, Barcelona as it is just ignored (all emails which are copied here were ignored too), my emails to @crg are filtered out even when I'm asked for reply by their officers.
Having experienced so mean-spirited lies and slandering from CRG tops, I would not like to know by the end of the day that my signature is forged.

Later I'll move all this on github to make it better seen.
